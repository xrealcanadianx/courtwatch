export default function Homepage(){
return <div style={{minHeight:'100vh',padding:'40px'}}>
<h1 style={{fontSize:'48px'}}>CourtWatch.ca</h1>
<p>Canadian Court Transparency Dashboard (Live Preview)</p>
</div>
}