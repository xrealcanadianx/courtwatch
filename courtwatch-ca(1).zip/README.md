# CourtWatch.ca
npm install
npm run dev
